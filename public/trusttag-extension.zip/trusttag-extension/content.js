chrome.runtime.onMessage.addListener((request) => {
  if (request.action === "rerun") {
    resetEvaluations();
    scanPageForProducts();
  }
});

function resetEvaluations() {
  document.querySelectorAll('.trusttag-evaluated').forEach((el) => {
    el.classList.remove('trusttag-evaluated');
    el.style.border = 'none';
    el.style.opacity = '1';
    const oldLabel = el.querySelector('.trusttag-alert');
    if (oldLabel) oldLabel.remove();
  });
}

// The actual fetch to /api/evaluate happens in background.js, not here —
// content scripts run inside the retailer's page and are subject to that
// page's CSP, which can silently block a direct fetch on some sites.
function evaluateRemotely(payload) {
  return chrome.runtime.sendMessage({ action: 'evaluateProduct', payload });
}

const ALLERGEN_KNOWLEDGE_GRAPH = {
  GLUTEN: ['gluten', 'wheat', 'barley', 'rye', 'spelt', 'kamut', 'triticale', 'malt', 'semolina', 'durum'],
  WHEAT: ['wheat'],
  PEANUTS: ['peanut', 'groundnut', 'arachis'],
  // "nut" is safe to keep bare now that the "-free" guard below exists —
  // "Nut Free" no longer false-positives — and it's needed because "may
  // contain nuts" advisories almost always use the generic word.
  TREE_NUTS: ['nut', 'almond', 'hazelnut', 'walnut', 'cashew', 'pecan', 'brazil nut', 'pistachio', 'macadamia'],
  SESAME: ['sesame', 'tahini', 'benne', 'gingelly'],
  MILK: ['milk', 'casein', 'caseinate', 'whey', 'butter', 'ghee', 'cheese', 'cream', 'lactalbumin', 'lactoglobulin', 'yogurt'],
  EGGS: ['egg', 'albumen', 'ovalbumin', 'lysozyme'],
  SOY: ['soy', 'soya', 'soybean', 'edamame', 'tofu', 'tempeh', 'miso'],
  FISH: ['fish', 'salmon', 'tuna', 'cod', 'haddock', 'anchovy', 'sardine'],
  CRUSTACEANS: ['crustacean', 'prawn', 'shrimp', 'crab', 'lobster', 'langoustine', 'krill'],
  MOLLUSCS: ['mollusc', 'mollusk', 'mussel', 'clam', 'oyster', 'scallop', 'squid', 'octopus', 'snail', 'whelk'],
  MUSTARD: ['mustard'],
  CELERY: ['celery', 'celeriac'],
  LUPIN: ['lupin', 'lupine'],
  SULPHITES: ['sulphite', 'sulfite', 'sulphur dioxide', 'sulfur dioxide', 'e220', 'e221', 'e222', 'e223', 'e224', 'e226', 'e227', 'e228']
};

const RESTRICTION_TO_CATEGORIES = {
  gluten: ['GLUTEN'],
  wheat_allergy: ['WHEAT'],
  peanuts: ['PEANUTS'],
  nuts: ['TREE_NUTS'],
  sesame: ['SESAME'],
  dairy_allergy: ['MILK'],
  lactose_intolerance: ['MILK'],
  seafood: ['FISH', 'CRUSTACEANS', 'MOLLUSCS'],
  fish: ['FISH'],
  crustaceans: ['CRUSTACEANS'],
  molluscs: ['MOLLUSCS'],
  eggs: ['EGGS'],
  soy: ['SOY'],
  mustard: ['MUSTARD'],
  celery: ['CELERY'],
  lupin: ['LUPIN'],
  sulphites: ['SULPHITES']
};

const MAY_CONTAIN_TO_CATEGORIES = {
  gluten: ['GLUTEN'],
  wheat_allergy: ['WHEAT'],
  peanuts: ['PEANUTS'],
  nuts: ['TREE_NUTS'],
  sesame: ['SESAME'],
  dairy_allergy: ['MILK'],
  seafood: ['FISH', 'CRUSTACEANS', 'MOLLUSCS'],
  fish: ['FISH'],
  crustaceans: ['CRUSTACEANS'],
  molluscs: ['MOLLUSCS'],
  mustard: ['MUSTARD'],
  celery: ['CELERY'],
  lupin: ['LUPIN'],
  sulphites: ['SULPHITES']
};

const KNOWN_ALIAS_TO_CANONICAL = {
  lactalbumin: 'milk',
  casein: 'milk',
  caseinate: 'milk',
  whey: 'milk',
  soya: 'soy',
  soybean: 'soy',
  sulphur: 'sulfur'
};

function normalizeInput(text = '') {
  let normalized = String(text).toLowerCase();
  normalized = normalized.replace(/[_/|]/g, ' ');
  normalized = normalized.replace(/[^\w\s%.,-]/g, ' ');
  normalized = normalized.replace(/\s+/g, ' ').trim();

  Object.entries(KNOWN_ALIAS_TO_CANONICAL).forEach(([alias, canonical]) => {
    normalized = normalized.replace(new RegExp(`\\b${alias}\\b`, 'g'), canonical);
  });

  return normalized;
}

// Grocery sites print this (or something like it) on essentially every
// product page: "Allergy Advice: For allergens, including cereals
// containing gluten, see ingredients in bold." It names allergens purely
// as an illustrative example of what bold text means, not as a statement
// about this product, so it must never reach the keyword matcher. Real
// ingredient/trace text essentially never uses the word "bold", so
// dropping any clause containing it is a safe, low-risk filter — but the
// clause must be BOUNDED on both sides. Without a bound, a source with no
// period near "bold" (several retailer pages concatenate ingredients/
// lifestyle/warnings into one run-on block with no punctuation between
// sections) lets this eat hundreds of characters of real, unrelated
// content in both directions. Confirmed live: a Waitrose bread page's
// real "Wheat flour..." ingredients were entirely swallowed this way,
// leaving only an unrelated "Lifestyle... Warnings..." tail and making
// the product look gluten-free.
function stripAdvisoryBoilerplate(text = '') {
  return String(text).replace(/[^.\n]{0,200}\bbold\b[^.\n]{0,200}[.\n]?/gi, ' ');
}

// Covers "Free From: Gluten, Wheat, Milk" style declaration panels.
// Bounded to a generous-but-finite length so an unpunctuated wall of real
// ingredients after a stray "free from" can't get silently swallowed too.
const FREE_FROM_CLAUSE = /\bfree\s*from\b\s*:?\s*[a-z0-9,\s-]{0,200}/gi;

// A "may contain X" clause is a trace/cross-contamination warning, not a
// statement that X is actually an ingredient. On most retailers that text
// lives in a cleanly separate Allergy Advice section, but Waitrose's
// "Ingredients" panel is one wrapping block that also swallows the
// allergy-advice and lifestyle-claims text right along with the real
// ingredients list (confirmed live: Border Lemon Drizzle Melts' extracted
// "ingredients" text ends in "...Allergy Advice May Contain Eggs May
// Contain Nuts Also, may contain traces of Egg and Nuts. Lifestyle..."). A
// naive "does this text mention nuts" check on that block wrongly promotes
// a caution-only cross-contamination warning into a hard "contains nuts"
// match — showing red (UNSAFE) instead of amber (CAUTION) for a user who
// has nuts as a hard restriction. lib/allergen-engine.ts on the server
// already strips these clauses out of ingredient detection and folds them
// into trace detection instead; this mirrors that exact split for the
// local, pre-relay evaluation so the two never disagree on severity.
const MAY_CONTAIN_PATTERN = /may contain[^.]+/gi;

function extractMayContainClauses(text = '') {
  return String(text).match(MAY_CONTAIN_PATTERN) || [];
}

function stripMayContainClauses(text = '') {
  return String(text).replace(MAY_CONTAIN_PATTERN, ' ');
}

function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function detectAllergenCategories(text = '') {
  const normalized = normalizeInput(text).replace(FREE_FROM_CLAUSE, ' ');
  const detected = new Set();

  Object.entries(ALLERGEN_KNOWLEDGE_GRAPH).forEach(([category, aliases]) => {
    const isPresent = aliases.some((alias) => {
      // "s?" tolerates plain English plurals ("Peanuts", "Almonds",
      // "Prawns" are all far more common on real labels than the
      // singular forms). "(?![\s-]*free\b)" then skips the match when the
      // very next word is "free" ("Gluten Free Oats") — a claim of
      // absence, not presence.
      const pattern = new RegExp(`\\b${escapeRegExp(alias)}s?\\b(?![\\s-]*free\\b)`, 'i');
      return pattern.test(normalized);
    });
    if (isPresent) detected.add(category);
  });

  return Array.from(detected);
}

function parseMacroData(text = '') {
  const normalized = normalizeInput(text).replace(/(\d),(\d)/g, '$1.$2');
  const carbs = normalized.match(/(carbohydrates?|carbs?)[^\d]{0,40}(\d+(?:\.\d+)?)/i);
  const protein = normalized.match(/(protein)[^\d]{0,40}(\d+(?:\.\d+)?)/i);

  return {
    ...(carbs ? { carbsPer100g: Number.parseFloat(carbs[2]) } : {}),
    ...(protein ? { proteinPer100g: Number.parseFloat(protein[2]) } : {})
  };
}

function categoriesFromIds(ids = [], mapping) {
  const set = new Set();
  ids.forEach((id) => {
    (mapping[id] || []).forEach((category) => set.add(category));
  });
  return set;
}

function evaluateLocally({ ingredients, traces, nutrition, restrictions, mayContainRestrictions, configuredMacros }) {
  const ingredientMayContainClauses = extractMayContainClauses(ingredients);
  const ingredientCategories = new Set(detectAllergenCategories(stripMayContainClauses(ingredients)));
  const traceCategories = new Set(detectAllergenCategories(`${traces} ${ingredientMayContainClauses.join(' ')}`));
  const restrictedCategories = categoriesFromIds(restrictions, RESTRICTION_TO_CATEGORIES);
  const traceSensitiveCategories = categoriesFromIds(mayContainRestrictions, MAY_CONTAIN_TO_CATEGORIES);

  const hardConflicts = [];
  restrictedCategories.forEach((category) => {
    if (ingredientCategories.has(category)) {
      hardConflicts.push(`Contains ${category}`);
    }
  });

  const cautionConflicts = [];
  traceSensitiveCategories.forEach((category) => {
    // Skip only if THIS category already produced a hard conflict above —
    // not merely because the user also listed it as a hard restriction.
    // Someone can have nuts as both a hard restriction and a "caution on
    // traces" pick; if the product has no nut ingredient but does carry a
    // "may contain nuts" warning, that's real information they asked for
    // and it must still surface as a caution, not get silently dropped
    // because nuts also happens to appear in restrictedCategories.
    if (traceCategories.has(category) && !ingredientCategories.has(category)) {
      cautionConflicts.push(`May contain ${category}`);
    }
  });

  const parsedMacros = parseMacroData(`${nutrition} ${ingredients} ${traces}`);
  if (
    typeof configuredMacros.maxCarbsPer100g === 'number' &&
    typeof parsedMacros.carbsPer100g === 'number' &&
    parsedMacros.carbsPer100g > configuredMacros.maxCarbsPer100g
  ) {
    hardConflicts.push(`Carbs ${parsedMacros.carbsPer100g}g/100g > limit ${configuredMacros.maxCarbsPer100g}g`);
  }

  if (
    typeof configuredMacros.minProteinPer100g === 'number' &&
    typeof parsedMacros.proteinPer100g === 'number' &&
    parsedMacros.proteinPer100g < configuredMacros.minProteinPer100g
  ) {
    hardConflicts.push(`Protein ${parsedMacros.proteinPer100g}g/100g < minimum ${configuredMacros.minProteinPer100g}g`);
  }

  const status = hardConflicts.length ? 'UNSAFE' : (cautionConflicts.length ? 'CAUTION' : 'SAFE');
  return {
    status,
    reasons: hardConflicts.length ? hardConflicts : cautionConflicts,
    ingredientCategories: Array.from(ingredientCategories),
    traceCategories: Array.from(traceCategories),
    parsedMacros
  };
}

function statusRank(status) {
  if (status === 'UNSAFE') return 2;
  if (status === 'CAUTION') return 1;
  return 0;
}

function inferApiStatus(data = {}) {
  if (typeof data.status === 'string') return data.status.toUpperCase();
  const reasons = (data.reasons || []).map((reason) => String(reason).toLowerCase());
  if (reasons.some((reason) => reason.includes('may contain') || reason.includes('trace'))) return 'CAUTION';
  return data.isSafe === false ? 'UNSAFE' : 'SAFE';
}

// Product pages commonly render each section as a heading (h2/h3/strong)
// immediately followed by a sibling element holding just that section's
// own text — but the SAME label text can appear in more than one shape:
//   - a broad accordion-index heading whose "next sibling" wraps the
//     entire page's worth of content (grabbing this instead of the real
//     section pulled in the whole page, nav bar and all, on Tesco)
//   - a bare label ("Ingredients", "Allergy Information") with the real
//     content in a sibling element
//   - a label FUSED with its content in one element ("May contain:
//     Barley, Wheat, Gluten..."), immediately followed by a totally
//     unrelated sibling label ("Contains: See highlighted ingredients") —
//     using the sibling here grabs the wrong thing entirely
//   - a label that ALSO appears inline, mid-paragraph, as its own
//     <strong> tag — e.g. "INGREDIENTS:" bolded at the start of the
//     ingredients text itself, per UK rules requiring allergens to be
//     bolded within the ingredients list. That inline tag's "next
//     sibling" is just whatever the next bolded word happens to be (often
//     a single allergen like "Milk") — a few characters that then wins
//     the smallest-candidate tiebreak and discards the real list
//     (confirmed live: Tesco Finest Chocolate & Salted Caramel Cake).
//   - on a multi-variant product (e.g. a mixed 9-pack with several
//     recipes, each with its own Ingredients panel), the server-rendered
//     HTML can flat-out mispair one "Ingredients" heading with the WRONG
//     sibling — landing on the Nutrition table instead — even though the
//     rendered, hydrated page pairs them correctly. If that mispaired
//     block happens to be shorter than every genuine ingredients block,
//     it wins the smallest-candidate tiebreak outright (confirmed live:
//     Tesco Finest Chocolate Selection Mini Cupcakes 9 Pack, where a
//     472-character nutrition table beat three genuine ~500-700 char
//     ingredient lists that all correctly mentioned wheat).
// isBareLabel() requires an exact match (not "contains this text
// anywhere") so an unrelated element mentioning the word "ingredients" in
// passing doesn't qualify as a candidate at all. For whatever candidates
// do match: if the heading's own text already has real content after a
// colon, that own text IS the section (fused case) — otherwise use its
// sibling (bare label case), but only when that sibling is a block-level
// container: a real section's content is a DIV/P/etc, never another bare
// STRONG/B, which is the tell that we've landed on inline emphasis
// rather than an actual section. A nutrition table has a very
// recognizable, boilerplate shape ("Typical Values" + "per 100") that a
// genuine ingredients or allergy section never has, so any candidate
// matching it is rejected outright before the smallest-wins tiebreak —
// that mispairing can otherwise slip past every other check. Among
// whatever's left, the SMALLEST is the real, specific section; a broad
// wrapper is always larger.
function isBareLabel(text, label) {
  return text.replace(/:\s*$/, '').trim() === label;
}

const INLINE_EMPHASIS_TAGS = new Set(['STRONG', 'B', 'EM', 'I']);
const HEADING_LIKE_SELECTOR = 'h1, h2, h3, h4, strong, dt, button';

function looksLikeNutritionTable(text) {
  return /typical values/i.test(text) && /per\s*100/i.test(text);
}

// Neither .innerText nor .textContent is safe to use alone for pulling
// text out of a retailer's markup:
//  - .textContent ignores layout entirely and concatenates sibling
//    elements with NO separator, so "<p>May contain Wheat</p><p>Suitable
//    for Vegetarians</p>" becomes "...WheatSuitable..." — breaking
//    word-boundary matching for "wheat" (confirmed live: Sainsbury's
//    Dietary Information panel).
//  - .innerText fixes that by respecting block-level layout, but it
//    requires the element to actually be rendered — it returns EMPTY for
//    a collapsed <details> panel's content, since the UA stylesheet
//    hides it (confirmed live: same Sainsbury's panel when collapsed).
//    It also doesn't help when items are styled as inline chips rather
//    than stacked lines (confirmed live: Waitrose's "Allergy Advice" list
//    concatenates into "AlmondsMay Contain Wheat" even with innerText).
// This walks the DOM directly and inserts a separator around every
// block-level element's contributed text, regardless of whether it's
// currently rendered/visible — the one approach that's reliable for a
// collapsed accordion, an inline-styled list, and a plain fetched
// (unattached, unrendered) document all at once.
const BLOCK_TAGS = new Set([
  'P', 'DIV', 'LI', 'TR', 'TD', 'BR', 'SECTION', 'ARTICLE', 'UL', 'OL',
  'H1', 'H2', 'H3', 'H4', 'H5', 'H6'
]);

function textWithBlockSeparators(el) {
  let result = '';
  for (const node of el.childNodes) {
    if (node.nodeType === Node.TEXT_NODE) {
      result += node.textContent;
    } else if (node.nodeType === Node.ELEMENT_NODE) {
      const childText = textWithBlockSeparators(node);
      const isBlock = BLOCK_TAGS.has(node.tagName);
      if (isBlock && result && !/\s$/.test(result)) result += ' ';
      result += childText;
      if (isBlock && childText && !/\s$/.test(childText)) result += ' ';
    }
  }
  return result;
}

function blockText(el) {
  return el ? textWithBlockSeparators(el).replace(/\s+/g, ' ').trim() : '';
}

function extractSectionAfterHeading(doc, matchLabel, { rejectNutritionTables = false } = {}) {
  const candidates = Array.from(doc.querySelectorAll(HEADING_LIKE_SELECTOR))
    .filter((el) => matchLabel(el.textContent.trim().toLowerCase()))
    .map((el) => {
      const ownText = el.textContent.trim();
      const colonIndex = ownText.indexOf(':');
      const hasInlineContent = colonIndex !== -1 && ownText.slice(colonIndex + 1).trim().length > 0;
      if (hasInlineContent) return ownText;
      const sibling = el.nextElementSibling;
      if (!sibling || INLINE_EMPHASIS_TAGS.has(sibling.tagName)) return '';
      return blockText(sibling);
    })
    .filter((text) => text && text.trim().length > 0)
    .filter((text) => !rejectNutritionTables || !looksLikeNutritionTable(text));

  if (!candidates.length) return '';

  return candidates.reduce((shortest, text) => (text.length < shortest.length ? text : shortest));
}

// Sainsbury's uses native <details>/<summary> accordions instead of a
// heading-plus-sibling layout — content lives inside the <details>
// element regardless of open/closed state, so no adjacency guessing is
// needed at all: find the exact-text label, walk up to its <details>,
// and strip the label's own text back off the front (its text is
// included, since the label is inside the same element tree).
function extractDetailsSection(doc, exactLabel) {
  const label = Array.from(doc.querySelectorAll('span, summary'))
    .find((el) => el.textContent.trim() === exactLabel);
  const details = label && label.closest('details');
  if (!details) return '';
  const fullText = blockText(details);
  return fullText.startsWith(exactLabel) ? fullText.slice(exactLabel.length).trim() : fullText;
}

function detectRetailer() {
  const host = window.location.hostname;
  if (host.includes('sainsburys.co.uk')) return 'sainsburys';
  if (host.includes('waitrose.com')) return 'waitrose';
  return 'tesco';
}

// Retailer pages often embed the product's real barcode in standard
// schema.org JSON-LD (for search engines), even though it's never shown
// on-screen. That lets the server cross-check the product against Open
// Food Facts by an exact barcode lookup instead of guessing from a name.
function extractBarcode(doc) {
  const scripts = Array.from(doc.querySelectorAll('script[type="application/ld+json"]'));
  for (const script of scripts) {
    let parsed;
    try {
      parsed = JSON.parse(script.textContent);
    } catch {
      continue;
    }
    const nodes = Array.isArray(parsed) ? parsed : (parsed['@graph'] || [parsed]);
    const product = nodes.find((node) => node && node['@type'] === 'Product');
    const gtin = product && (product.gtin13 || product.gtin || product.gtin12 || product.gtin8);
    if (typeof gtin === 'string' && /^\d{8,14}$/.test(gtin.trim())) return gtin.trim();
  }
  return '';
}

const PRODUCT_PAGE_TIMEOUT_MS = 8000;

async function fetchProductDetails(url) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), PRODUCT_PAGE_TIMEOUT_MS);
  try {
    const response = await fetch(url, { signal: controller.signal });
    const html = await response.text();
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const retailer = detectRetailer();

    let ingredients;
    let traces;
    let nutrition;

    if (retailer === 'sainsburys') {
      // Confirmed live: Sainsbury's product pages use native <details>
      // accordions labelled Ingredients / Dietary Information / Nutrition
      // (no separate "Allergy" section — "May contain X, Y" lives inside
      // Dietary Information alongside things like "Suitable for Vegetarians").
      ingredients = extractDetailsSection(doc, 'Ingredients');
      traces = extractDetailsSection(doc, 'Dietary Information');
      nutrition = extractDetailsSection(doc, 'Nutrition');
    } else {
      // Tesco and Waitrose (and Ocado, untested but structurally similar)
      // both use a heading/button immediately followed by a sibling
      // holding the section's content — just with different label
      // wording per retailer ("Allergy Information" vs "Allergy Advice",
      // "Nutrition Information" vs "Nutrition").
      ingredients = extractSectionAfterHeading(
        doc,
        (text) => isBareLabel(text, 'ingredients'),
        { rejectNutritionTables: true }
      );
      traces = extractSectionAfterHeading(
        doc,
        (text) =>
          isBareLabel(text, 'allergy information') ||
          isBareLabel(text, 'allergy advice') ||
          text.startsWith('may contain'),
        { rejectNutritionTables: true }
      );
      nutrition = extractSectionAfterHeading(
        doc,
        (text) => isBareLabel(text, 'nutrition information') || isBareLabel(text, 'nutrition')
      );
    }

    const barcode = extractBarcode(doc);

    return { ingredients, traces, nutrition, barcode };
  } catch (e) {
    // Rethrow rather than swallow: a caller that got {ingredients: ''}
    // back on a genuine network failure or timeout has no way to tell
    // that apart from "this product legitimately has no ingredients
    // text" — and would go on to evaluate against empty data, which
    // reads as SAFE. That's a false negative for a safety-critical
    // check. Letting this propagate means the card falls into the same
    // retry-on-next-scan path as any other failed evaluation, instead of
    // silently showing an unverified product as safe.
    console.error("TrustTag: deep scan failed for URL:", url, e);
    throw e;
  } finally {
    clearTimeout(timeout);
  }
}

// Caps how many product cards are evaluated at once, instead of firing
// every card on a busy listing page near-simultaneously — kinder to the
// retailer's own site and to Open Food Facts, and keeps a slow/failing
// card from stalling everything behind it (doubly so now that each
// fetch has its own timeout, so a stuck one only occupies a slot for a
// bounded time rather than indefinitely). No longer tuned around
// Gemini's tiny free-tier rate limit — that dependency is gone — so this
// can run higher than the original 3.
const EVALUATION_CONCURRENCY = 6;

async function runWithConcurrencyLimit(items, limit, worker) {
  const queue = items.slice();
  async function runNext() {
    const item = queue.shift();
    if (item === undefined) return;
    await worker(item);
    return runNext();
  }
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, runNext));
}

// Retailers change their markup without notice, and none of these were
// taken on faith — each was confirmed live against a real search/listing
// page. Tesco's card selectors were already working; Sainsbury's
// ([data-testid="gw-product-card"]) and Waitrose ([data-testid=
// "product-pod"]) were verified directly (60/60 and 48/48 cards matched
// with a real product link inside, respectively) when onboarding them.
// Sainsbury's later turned out to load far more cards per search than
// either (120 confirmed live on a "chocolate" search, vs Tesco's ~24) —
// relevant to the retry logic below.
const PRODUCT_SELECTORS = [
  'li.WL_DZkV_Rvg0WJi',
  'li.product-list--list-item',
  'div.product-tile-wrapper',
  '[data-testid^="product-tile"]',
  '[data-testid="gw-product-card"]',
  '[data-testid="product-pod"]'
];
const PRODUCT_SELECTOR_STRING = PRODUCT_SELECTORS.join(',');

function hasUnresolvedCards() {
  return document.querySelector(`${PRODUCT_SELECTOR_STRING}:not(.trusttag-evaluated)`) !== null;
}

// Listing pages (especially a broad search like "chocolate", with lots of
// lazy-loaded images) mutate the DOM continuously, which retriggers a
// rescan via the MutationObserver below while an earlier scan's per-card
// evaluations may still be in flight. resetEvaluations() strips the
// "already evaluated" marker but has no way to cancel that older,
// still-running work — so both the stale and fresh evaluations for the
// same card can finish and write to it, in either order. Whichever
// finishes LAST wins, which is sometimes the stale one.
//
// This used to be guarded with a single page-wide generation counter,
// bumped on every scan and compared before each write. That over-fired:
// ANY scan retrigger anywhere on the page — even one that never touches
// this card at all — bumped the shared counter and made every
// still-in-flight evaluation from the previous scan look "stale", so its
// result was silently discarded. The card stayed marked
// 'trusttag-evaluated' (it was never re-claimed, since it wasn't part of
// the new scan's actual work), so nothing ever retried it either — a
// permanent, uncoloured card. Confirmed live: this barely shows on Tesco
// (~24 cards, first pass usually finishes before the 6s retrigger even
// fires) but is common on Sainsbury's, where a single search page loads
// 120+ cards and the first pass alone can still be mid-flight when a
// retrigger fires, discarding a chunk of in-flight work every time.
//
// The fix scopes the guard to the individual card instead of the whole
// page: each claim gets its own token, and a result only gets discarded
// if THIS SAME card was independently re-claimed by a newer scan (the
// actual race resetEvaluations() can cause) — never just because some
// other card elsewhere started a new scan.
const cardClaimToken = new WeakMap();

async function scanPageForProducts() {
  const cards = document.querySelectorAll(PRODUCT_SELECTOR_STRING);
  chrome.storage.local.get(['userRestrictions', 'userMayContains', 'userMacros'], async (storedData) => {
    const restrictions = storedData.userRestrictions || [];
    const mayContainRestrictions = storedData.userMayContains || [];
    const macros = storedData.userMacros || {};

    await runWithConcurrencyLimit(Array.from(cards), EVALUATION_CONCURRENCY, async (card) => {
      if (card.classList.contains('trusttag-evaluated')) return;
      card.classList.add('trusttag-evaluated');
      const claimToken = Symbol();
      cardClaimToken.set(card, claimToken);

      // Sainsbury's product URLs are singular ("/product/…"); Tesco and
      // Waitrose are plural ("/products/…") — this substring matches both.
      const productLink = card.querySelector('a[href*="/product"]');
      if (!productLink) return;

      const productUrl = productLink.href;
      const title = card.innerText.split('\n')[0];

      try {
        const rawDetails = await fetchProductDetails(productUrl);
        const details = {
          ...rawDetails,
          ingredients: stripAdvisoryBoilerplate(rawDetails.ingredients),
          traces: stripAdvisoryBoilerplate(rawDetails.traces)
        };
        const localEvaluation = evaluateLocally({
          ingredients: details.ingredients || title,
          traces: details.traces,
          nutrition: details.nutrition,
          restrictions,
          mayContainRestrictions,
          configuredMacros: macros
        });

        const relayResult = await evaluateRemotely({
          name: title,
          raw_ingredients: details.ingredients || title,
          manufacturing_traces: details.traces,
          nutrition_text: details.nutrition,
          normalized_ingredients: normalizeInput(details.ingredients || title),
          normalized_traces: normalizeInput(details.traces),
          detected_ingredient_categories: localEvaluation.ingredientCategories,
          detected_trace_categories: localEvaluation.traceCategories,
          extracted_macros: localEvaluation.parsedMacros,
          restrictions,
          mayContainRestrictions,
          macros,
          product_barcode: details.barcode
        });

        if (!relayResult || !relayResult.ok) {
          throw new Error((relayResult && relayResult.error) || 'TrustTag background relay failed');
        }

        // This exact card has since been re-claimed by a newer scan (only
        // possible after resetEvaluations() unmarks it) — that newer
        // attempt's result will land separately. Applying this stale one
        // now could overwrite a correct, fresher result with an outdated
        // one.
        if (cardClaimToken.get(card) !== claimToken) return;

        const data = relayResult.data;
        const existingAlert = card.querySelector('.trusttag-alert');
        if (existingAlert) existingAlert.remove();

        const remoteStatus = inferApiStatus(data);
        const finalStatus = statusRank(localEvaluation.status) > statusRank(remoteStatus) ? localEvaluation.status : remoteStatus;
        const finalReasons = statusRank(localEvaluation.status) > statusRank(remoteStatus)
          ? localEvaluation.reasons
          : (data.reasons || localEvaluation.reasons);

        if (finalStatus === 'SAFE') {
          card.style.border = '4px solid #22b28c';
          card.style.position = 'relative';
          card.style.opacity = '1';
        } else if (finalStatus === 'CAUTION') {
          card.style.border = '4px solid #e0a63e';
          card.style.position = 'relative';
          card.style.opacity = '1';

          const cautionLabel = document.createElement('div');
          cautionLabel.className = 'trusttag-alert';
          cautionLabel.innerText = `⚠️ ${finalReasons[0] || 'MAY CONTAIN - CAUTION'}`;
          cautionLabel.style.cssText = 'background:#e0a63e; color:#111827; font-size:10px; padding:6px; font-weight:bold; text-align:center; position:absolute; top:0; left:0; right:0; z-index:100;';
          card.appendChild(cautionLabel);
        } else {
          card.style.border = '4px solid #e2596b';
          card.style.opacity = '0.45';
          card.style.position = 'relative';

          const alertLabel = document.createElement('div');
          alertLabel.className = 'trusttag-alert';
          alertLabel.innerText = `⚠️ ${finalReasons[0] || 'DIETARY CONFLICT'}`;
          alertLabel.style.cssText = 'background:#e2596b; color:white; font-size:10px; padding:6px; font-weight:bold; text-align:center; position:absolute; top:0; left:0; right:0; z-index:100;';
          card.appendChild(alertLabel);
        }
      } catch (err) {
        console.error("TrustTag: evaluation failed for", title, err);
        card.classList.remove('trusttag-evaluated');
      }
    });
  });
}

scanPageForProducts();

// A failed card (timeout, transient network error) has its
// 'trusttag-evaluated' marker removed so a future scan will pick it back
// up — but on a page that stops mutating after the initial load, nothing
// would ever trigger that future scan, and the card would just sit
// unevaluated forever. This used to be two fixed one-off passes (6s,
// 15s), which was plenty for a small listing page but not for
// Sainsbury's: a single search page there commonly loads 120+ cards
// (confirmed live), and the very first pass alone can still be working
// through the concurrency-limited queue well past 15s — so a card that
// failed after that point had nothing left to ever retry it. Polling on
// a fixed cadence instead, and stopping only once nothing's left
// unresolved (or a generous attempt cap, so a page that's genuinely done
// mutating doesn't get polled forever), scales to any page size
// automatically: it clears itself after a poll or two on a small page
// exactly like Tesco's, and keeps going as long as Sainsbury's actually
// needs it to.
const RETRY_POLL_MS = 5000;
const RETRY_MAX_ATTEMPTS = 20;
let retryAttempts = 0;
const retryTimer = setInterval(() => {
  retryAttempts += 1;
  if (!hasUnresolvedCards() || retryAttempts >= RETRY_MAX_ATTEMPTS) {
    clearInterval(retryTimer);
    return;
  }
  scanPageForProducts();
}, RETRY_POLL_MS);

const observer = new MutationObserver(() => {
  clearTimeout(window.trusttagTimeout);
  // Longer than a single evaluation typically takes (product-page fetch +
  // server round trip), so a busy, continuously-mutating listing page
  // doesn't retrigger a rescan every 500ms while the last one is still
  // running — the generation guard above makes that safe either way, but
  // this cuts down on redundant work.
  window.trusttagTimeout = setTimeout(scanPageForProducts, 1200);
});

observer.observe(document.body, { childList: true, subtree: true });
