// Runs the actual /api/evaluate fetch from the extension's own background
// context, not the content script. Content scripts execute inside the
// retailer's page and are subject to that page's Content-Security-Policy —
// a site with a restrictive connect-src can silently block a fetch made
// from content.js ("TypeError: Failed to fetch", no CORS error, nothing
// useful in Network tab). The background service worker has no such
// restriction, so this is the reliable place to make cross-origin calls.
const TRUSTTAG_API_URL = 'https://omnisearch-landing.vercel.app/api/evaluate';
const TRUSTTAG_API_KEY = '5a851dea145c2fea0b0391ce72538154daea531ccfac9c00';
const RELAY_TIMEOUT_MS = 8000;

chrome.runtime.onMessage.addListener((request, _sender, sendResponse) => {
  if (request.action !== 'evaluateProduct') return false;

  // Without a timeout, one slow/hung request occupies one of only a
  // handful of concurrent evaluation slots on the content-script side
  // indefinitely, stalling everything else queued behind it on a busy
  // listing page. Fail fast instead so the queue keeps moving.
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), RELAY_TIMEOUT_MS);

  fetch(TRUSTTAG_API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': TRUSTTAG_API_KEY
    },
    body: JSON.stringify(request.payload),
    signal: controller.signal
  })
    .then(async (response) => {
      if (!response.ok) {
        sendResponse({ ok: false, error: `TrustTag API returned ${response.status}` });
        return;
      }
      const data = await response.json();
      sendResponse({ ok: true, data });
    })
    .catch((error) => {
      sendResponse({ ok: false, error: String(error && error.message ? error.message : error) });
    })
    .finally(() => clearTimeout(timeout));

  return true; // keep the message channel open for the async response above
});
