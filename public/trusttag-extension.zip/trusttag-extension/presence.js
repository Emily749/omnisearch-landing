// Lets trusttag.com detect that the companion is installed, so it can show
// the right "install" or "active" state on the /shop page.
(function () {
  function announce() {
    window.postMessage(
      { type: "TRUSTTAG_EXTENSION_PRESENT", version: chrome.runtime.getManifest().version },
      window.location.origin
    );
  }

  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    if (event.data && event.data.type === "TRUSTTAG_PING") announce();
  });

  announce();
})();
