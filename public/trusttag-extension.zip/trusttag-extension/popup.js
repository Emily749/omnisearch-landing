// Public Supabase project values (safe to ship in a client) — same project
// as the TrustTag website. Fill these in once you've created the project;
// see the extension README for where to find them.
const SUPABASE_URL = 'https://YOUR_PROJECT.supabase.co';
const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';
const TRUSTTAG_SIGNUP_URL = 'https://omnisearch-landing.vercel.app/signup';

const ingredientsList = [
  'gluten', 'wheat_allergy', 'peanuts', 'nuts', 'sesame', 'dairy_allergy',
  'lactose_intolerance', 'seafood', 'fish', 'crustaceans', 'molluscs', 'eggs',
  'soy', 'mustard', 'celery', 'lupin', 'sulphites', 'vegan', 'vegetarian',
  'low_fodmap', 'halal', 'kosher', 'type2_diabetes'
];

const tracesList = [
  'gluten', 'wheat_allergy', 'peanuts', 'nuts', 'sesame', 'dairy_allergy',
  'fish', 'crustaceans', 'molluscs', 'mustard', 'celery', 'lupin', 'sulphites'
];

function loadCheckboxesFromStorage() {
  chrome.storage.local.get(['userRestrictions', 'userMayContains', 'userMacros'], (result) => {
    const activeRes = result.userRestrictions || [];
    const activeMC = result.userMayContains || [];
    const activeMacros = result.userMacros || {};

    ingredientsList.forEach((item) => {
      const el = document.getElementById(`res-${item}`);
      if (el) el.checked = activeRes.includes(item);
    });

    tracesList.forEach((item) => {
      const el = document.getElementById(`mc-${item}`);
      if (el) el.checked = activeMC.includes(item);
    });

    document.getElementById('macro-maxCarbs').value = activeMacros.maxCarbsPer100g ?? '';
    document.getElementById('macro-minProtein').value = activeMacros.minProteinPer100g ?? '';
  });
}

function saveFromCheckboxes(onDone) {
  const restrictions = ingredientsList.filter((item) => document.getElementById(`res-${item}`)?.checked);
  const mayContainRestrictions = tracesList.filter((item) => document.getElementById(`mc-${item}`)?.checked);

  const macros = {};
  const maxCarbs = document.getElementById('macro-maxCarbs').value;
  const minProtein = document.getElementById('macro-minProtein').value;
  if (maxCarbs) macros.maxCarbsPer100g = parseFloat(maxCarbs);
  if (minProtein) macros.minProteinPer100g = parseFloat(minProtein);

  chrome.storage.local.set(
    { userRestrictions: restrictions, userMayContains: mayContainRestrictions, userMacros: macros },
    () => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) chrome.tabs.sendMessage(tabs[0].id, { action: 'rerun' });
      });
      if (onDone) onDone();
    }
  );
}

function applyProfileFromServer(row) {
  const restrictions = row.restrictions || [];
  const mayContain = row.may_contain || [];
  const macros = row.macros || {};

  chrome.storage.local.set(
    { userRestrictions: restrictions, userMayContains: mayContain, userMacros: macros },
    () => {
      loadCheckboxesFromStorage();
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) chrome.tabs.sendMessage(tabs[0].id, { action: 'rerun' });
      });
    }
  );
}

function setSyncError(message) {
  const el = document.getElementById('sync-error');
  if (!message) {
    el.classList.add('hidden');
    el.textContent = '';
    return;
  }
  el.textContent = message;
  el.classList.remove('hidden');
}

function showSignedOutUI() {
  document.getElementById('sync-signed-out').classList.remove('hidden');
  document.getElementById('sync-signed-in').classList.add('hidden');
}

function showSignedInUI(email) {
  document.getElementById('sync-email').textContent = email;
  document.getElementById('sync-signed-out').classList.add('hidden');
  document.getElementById('sync-signed-in').classList.remove('hidden');
}

async function supabaseSignIn(email, password) {
  const response = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
    method: 'POST',
    headers: { apikey: SUPABASE_ANON_KEY, 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password })
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error_description || data.msg || 'Sign in failed.');
  return data;
}

async function supabaseRefresh(refreshToken) {
  const response = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
    method: 'POST',
    headers: { apikey: SUPABASE_ANON_KEY, 'Content-Type': 'application/json' },
    body: JSON.stringify({ refresh_token: refreshToken })
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error_description || data.msg || 'Session expired.');
  return data;
}

async function supabaseFetchProfile(accessToken, userId) {
  const response = await fetch(
    `${SUPABASE_URL}/rest/v1/profiles?select=restrictions,may_contain,macros&id=eq.${userId}`,
    { headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${accessToken}` } }
  );
  if (!response.ok) throw new Error('Could not load your profile.');
  const rows = await response.json();
  return rows[0] || { restrictions: [], may_contain: [], macros: {} };
}

async function syncFromSession(session, { silent } = {}) {
  try {
    const row = await supabaseFetchProfile(session.access_token, session.user.id);
    applyProfileFromServer(row);
    showSignedInUI(session.user.email);
    setSyncError(null);
  } catch (err) {
    if (session.refresh_token) {
      try {
        const refreshed = await supabaseRefresh(session.refresh_token);
        const newSession = {
          access_token: refreshed.access_token,
          refresh_token: refreshed.refresh_token,
          user: refreshed.user
        };
        chrome.storage.local.set({ trusttagSession: newSession }, async () => {
          const row = await supabaseFetchProfile(newSession.access_token, newSession.user.id);
          applyProfileFromServer(row);
          showSignedInUI(newSession.user.email);
          setSyncError(null);
        });
        return;
      } catch {
        // fall through to signed-out state below
      }
    }
    if (!silent) setSyncError('Your session expired — please sign in again.');
    chrome.storage.local.remove('trusttagSession');
    showSignedOutUI();
  }
}

document.addEventListener('DOMContentLoaded', () => {
  loadCheckboxesFromStorage();

  chrome.storage.local.get(['trusttagSession'], (result) => {
    if (result.trusttagSession) {
      syncFromSession(result.trusttagSession, { silent: true });
    } else {
      showSignedOutUI();
    }
  });

  document.getElementById('sign-in-btn').addEventListener('click', async () => {
    const email = document.getElementById('auth-email').value.trim();
    const password = document.getElementById('auth-password').value;
    if (!email || !password) {
      setSyncError('Enter your email and password.');
      return;
    }
    setSyncError(null);
    try {
      const data = await supabaseSignIn(email, password);
      const session = { access_token: data.access_token, refresh_token: data.refresh_token, user: data.user };
      chrome.storage.local.set({ trusttagSession: session }, () => syncFromSession(session));
    } catch (err) {
      setSyncError(err.message);
    }
  });

  document.getElementById('refresh-btn').addEventListener('click', () => {
    chrome.storage.local.get(['trusttagSession'], (result) => {
      if (result.trusttagSession) syncFromSession(result.trusttagSession);
    });
  });

  document.getElementById('sign-out-btn').addEventListener('click', () => {
    chrome.storage.local.remove('trusttagSession', () => {
      setSyncError(null);
      showSignedOutUI();
    });
  });

  document.getElementById('open-signup').addEventListener('click', (event) => {
    event.preventDefault();
    chrome.tabs.create({ url: TRUSTTAG_SIGNUP_URL });
  });

  document.getElementById('save-btn').addEventListener('click', () => {
    saveFromCheckboxes(() => window.close());
  });
});
